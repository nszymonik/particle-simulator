Nicholas Szymonik
nszymoni
G01171582
Lecture: DL2